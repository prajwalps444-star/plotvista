# PlotVista — Real Estate Listing Website

A responsive, GitHub Pages-ready static website for showcasing plots and properties.

## Features
- Property cards with photos, asking price, location, area in sq.ft. and dimensions
- Search by location/title, property-type filter and budget filter
- Click a listing for complete details, owner information and call/email/WhatsApp actions
- Responsive mobile layout

## Edit your property listings
Open `script.js`. The `properties` array contains demo listings. Replace each sample with your verified property data:
- `title`, `type`, `price`, `priceText`, `location`
- `area` (square feet), `dimensions`, `facing`, `road`
- `approval`, `water`, `electricity`
- `owner`, `phone` (include country code, e.g. +91), `email`
- `description`, `image` (a direct image URL)

Update the contact phone/email in `index.html` too. Do not publish private owner contact details without permission. Verify ownership, approvals, survey number, dimensions and price before publishing.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new **public** repository, for example `plotvista`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root (or use **Add file → Upload files**).
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish. Your site URL will look like `https://YOUR-USERNAME.github.io/plotvista/`.

This is a front-end demo. Listing changes are made by editing `script.js` and uploading the updated file. It does not have a secure admin panel or database yet.
